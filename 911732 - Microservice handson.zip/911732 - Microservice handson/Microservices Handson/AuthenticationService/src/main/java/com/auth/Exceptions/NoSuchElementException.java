package com.auth.Exceptions;

public class NoSuchElementException extends RuntimeException {

	public NoSuchElementException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	
}
